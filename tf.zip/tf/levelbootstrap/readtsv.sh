#!/bin/bash
file='subs.tsv'
#cancello il file se esistente
if [ -f "$file" ] ; then
    rm "$file"
fi

#leggo le sottoscrizioni da azure
az account list --query "[].{SubscriptionName:name, SubscriptionID:id}" --output tsv >> $file

#creo cartelle in base al file generato da Azure 
     while IFS=$'\t' read -r -a cell
     do
          for x in "${cell[0]:0}" #se al posto di 0 metto 1 ho l'ID della subs
          do   
            dir=${x%.*}
           if [ ! -d "$x" ];
           then
                mkdir -p "../../../Level2/$x/data"  && touch "../../../Level2/$x/subscription.tf" && touch "../../../Level2/$x/providers.tf"
                cp .gitignore "../../../Level2/$x/"
                cp ./level2/main.tf "../../../Level2/$x/"
                cat > "../../../Level2/$x/subscription.tf" << ENDOFFILE
  locals {
  subscription_id = "${cell[1]:0}"
 }
 
ENDOFFILE
                cat > "../../../Level2/$x/providers.tf" << ENDOFFILE
terraform {
  required_providers {
    azurerm = {
      source = "hashicorp/azurerm"
      version = "3.75.0"
    }
  }
    backend "azurerm" {
      #resource_group_name  = "ISP_DevOps"
      storage_account_name  = "ispsaremotestate"
      container_name        = "level2"
      key                   = "${x}_RSG.tfstate"
      use_azuread_auth      = true
      subscription_id       = "5a3e7a45-8f0a-4cb3-aef2-38d3c6a9bd07" #sbuscriptions where storage account has been created
      tenant_id             = "a361c185-fe1a-40f6-8734-767962e0dd5d"
  }
}

provider "azurerm" {
    subscription_id = local.subscription_id
    # Configuration options
    features {}
}
ENDOFFILE
             mkdir -p "../../../Level3/$x/data"  && touch "../../../Level3/$x/subscription.tf" && touch "../../../Level3/$x/providers.tf"
             mkdir -p "../../../Level3/$x/permissions" && mkdir -p "../../../Level3/$x/policies" && mkdir -p "../../../Level3/$x/sa" && mkdir -p "../../../Level3/$x/la" 
             cp .gitignore "../../../Level3/$x/"
             cat > "../../../Level3/$x/subscription.tf" << ENDOFFILE
  locals {
  subscription_id = "${cell[1]:0}"
 }
 
ENDOFFILE

             mkdir -p "../../../Level5/$x/data"  && touch "../../../Level5/$x/subscription.tf" && touch "../../../Level5/$x/providers.tf"
             cp .gitignore "../../../Level5/$x/"
             cat > "../../../Level5/$x/subscription.tf" << ENDOFFILE
  locals {
  subscription_id = "${cell[1]:0}"
 }
 
ENDOFFILE
            
            
            
            echo "$x Created"
           fi
          done
          echo ""
     done < "$file"
